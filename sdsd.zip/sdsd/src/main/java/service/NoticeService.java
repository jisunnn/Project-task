package service;

import java.util.List;

import vo.NoticeVO;

public interface NoticeService {

	// **  CRUD
	List<NoticeVO> selectList(); //selectList
	
	NoticeVO selectOne(NoticeVO vo); //selectOne
	
	int insert(NoticeVO vo); //insert
	
	int update(NoticeVO vo); //update
	
	int delete(NoticeVO vo); //delete
	

}