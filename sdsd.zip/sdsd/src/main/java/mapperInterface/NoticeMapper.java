package mapperInterface;

import java.util.List;

import vo.NoticeVO;

public interface NoticeMapper {
	
	 
	// **  CRUD
	List<NoticeVO> selectList(); //selectList
	
	NoticeVO selectOne(NoticeVO vo); //selectOne
	
	int insert(NoticeVO vo); //insert
	
	int update(NoticeVO vo); //update
	
	int delete(NoticeVO vo); //delete
	
	
} //interface
