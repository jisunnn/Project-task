package util_OLD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import vo.NoticeVO;

//** DAO (Data Access Object)
//=> CRUD 구현 
// C: create -> insert
// R: read   -> selectList, selectOne
// U: update -> update
// D: delete -> delete

//=> 전역변수 정의 , 메서드 작성
@Repository
public class NoticeDAO {
	
	Connection cn = DBConnection.getConnection();
	Statement st;
	PreparedStatement pst;
	ResultSet rs;
	String sql;
	
	// ** selectList
	public List<NoticeVO> selectList() {
		sql="select seq, title, regdate, id, cnt from notice" ;
		List<NoticeVO> list = new ArrayList<NoticeVO>();
		try {
			st=cn.createStatement();
			rs=st.executeQuery(sql);
			// 요청객체로 결과 전달
			// => 출력자료가 있는지 확인
			if (rs.next()) {
				// => 출력자료 1row -> vo 에 set  -> list 에 add 
				do {
					NoticeVO vo = new NoticeVO();
					vo.setSeq(rs.getInt(1));
					vo.setTitle(rs.getString(2));
					vo.setRegdate(rs.getString(3));
					vo.setContent(rs.getString(4));
					vo.setId(rs.getString(5));
					vo.setCnt(rs.getInt(6));
					list.add(vo);
				}while(rs.next());
			}else {
				System.out.println("** selectList: 출력 자료가 없습니다 ~~");
				list=null;
			}
		} catch (Exception e) {
			System.out.println("** selectList Exception => "+e.toString());
			list=null;
		}
		return list;
	} //selectList 

	// ** selectOne
	public NoticeVO selectOne(NoticeVO vo) {
		sql="select * from notice where seq=?" ;
		try {
			pst=cn.prepareStatement(sql);
			pst.setInt(1,vo.getSeq());
			rs = pst.executeQuery();
			// 결과 확인
			if (rs.next()) {
				vo.setSeq(rs.getInt(1));
				vo.setTitle(rs.getString(2));
				vo.setRegdate(rs.getString(3));
				vo.setContent(rs.getString(4));
				vo.setId(rs.getString(5));
				vo.setCnt(rs.getInt(6));
			}else {
				System.out.println("** 글번호에 해당하는 자료가 없습니다 ~~ **");
				vo=null;
			} //else
		} catch (Exception e) {
			System.out.println("** selectOne Exception => "+e.toString());
			vo=null;
		}
		return vo;
	} //selectOne	
	
	// ** 새글등록 -> insert
	// ** MySQL 
	//sql="insert into board(title,id,content) values(?,?,?)";
	     // insert into board (title,id,content) values ('Spring 이란?','green','처음엔 ~~~ 편리하다'); 
	public int insert(NoticeVO vo) {
		// ** Oracle : seq 에 nvl함수 적용 
		sql="insert into notice values("
				+ "(select nvl(max(seq),0)+1 from notice)"
				+ ",?,systimestamp,?,?,0)";
		try {
			pst=cn.prepareStatement(sql);
			pst.setString(1,vo.getTitle());
			pst.setString(2,vo.getContent());
			pst.setString(3,vo.getId());
			return pst.executeUpdate();
			// executeUpdate() => 처리된 row 의 갯수 return
		} catch (Exception e) {
			System.out.println("** insert Exception => "+e.toString());
			return 0;
		}
	} //insert
	
	// ** Update
	public int update(NoticeVO vo) {
		sql="update notice set title=?,content=? where seq=?";
		try {
			pst=cn.prepareStatement(sql);
			pst.setString(1,vo.getTitle());
			pst.setString(2,vo.getContent());
			pst.setInt(3,vo.getSeq());
			return pst.executeUpdate();
			// executeUpdate() => 처리된 row 의 갯수 return
		} catch (Exception e) {
			System.out.println("** update Exception => "+e.toString());
			return 0;
		}
	} //update
	
	// ** Delete
	// => 답글 추가후
	//	  - 원글삭제시 : 하위글모두 삭제
	//    - 답글삭제시 : 해당답글만 삭제
	public int delete(NoticeVO vo) {
		sql="delete from notice where seq=?";
		try {
			pst=cn.prepareStatement(sql);
			pst.setInt(1, vo.getSeq());
			return pst.executeUpdate() ;
		} catch (Exception e) {
			System.out.println("** delete Exception => "+e.toString());
			return 0;
		}
	} //delete

} // class
