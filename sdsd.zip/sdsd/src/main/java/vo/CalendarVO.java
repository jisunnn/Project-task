package vo;

import lombok.Data;

@Data
public class CalendarVO {
	private String caid;
	private String title;
	private String start_date;
	private String end_date;
	private String create_date;
} //vo
