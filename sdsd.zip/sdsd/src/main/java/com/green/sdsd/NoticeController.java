package com.green.sdsd;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import service.NoticeService;
import vo.AskVO;
import vo.NoticeVO;

@Controller
public class NoticeController {
	@Autowired
	NoticeService service;
       
	@RequestMapping(value = "/nlist")
	public ModelAndView nlist(ModelAndView mv) {
		
		List<NoticeVO> list = new ArrayList<NoticeVO>();
    	list = service.selectList();
    	
    	// => Mapper 는 null 을 return 하지 않으므로 길이로 확인 
    	if ( list!=null && list.size()>0 ) mv.addObject("nbanana", list);
    	else mv.addObject("message", "~~ 출력 자료가 없습니다 ~~");
		
    	mv.setViewName("board/noticeList");
		return mv;
	} //nlist
	
	@RequestMapping(value = "/ndetail")
	public ModelAndView ndetail(HttpServletRequest request, ModelAndView mv, NoticeVO vo) {
		
		String uri = "board/noticeDetail";
		vo = service.selectOne(vo);
    	if ( vo!=null ) {
    		mv.addObject("napple", vo);
    	}else {
    		mv.addObject("message", "글번호에 해당하는 자료가 없습니다");
    	}
		mv.setViewName(uri);
		return mv;
	} //ndetail
	
}
