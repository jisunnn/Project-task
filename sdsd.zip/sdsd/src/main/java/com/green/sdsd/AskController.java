package com.green.sdsd;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import service.AskService;
import vo.AskVO;

@Controller
public class AskController {
	@Autowired
	AskService service;
       
	@RequestMapping(value = "/alist")
	public ModelAndView alist(ModelAndView mv) {
		
		List<AskVO> list = new ArrayList<AskVO>();
    	list = service.selectList();
    	
    	// => Mapper 는 null 을 return 하지 않으므로 길이로 확인 
    	if ( list!=null && list.size()>0 ) mv.addObject("abanana", list);
    	else mv.addObject("message", "출력 자료가 없습니다 ");
		
    	mv.setViewName("board/askList");
		return mv;
	} //alist
	
	@RequestMapping(value = "/adetail")
	public ModelAndView adetail(HttpServletRequest request, ModelAndView mv, AskVO vo) {
		
		String uri = "board/askDetail";
		vo = service.selectOne(vo);
    	if ( vo!=null ) {
    		mv.addObject("aapple", vo);
    	}else {
    		mv.addObject("message", "글번호에 해당하는 자료가 없습니다");
    	}
		mv.setViewName(uri);
		return mv;
	} //adetail
	
}
