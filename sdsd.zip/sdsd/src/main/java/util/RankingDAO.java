package util;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import vo.RankingVO;

@Repository
public class RankingDAO {
	
	@Autowired
	SqlSession sqlSession;
	private static final String NS="sdsd.mapper.RankingMapper.";
	
	
	
	// ** selectList
	public List<RankingVO> selectList() {
		return sqlSession.selectList(NS+"selectList");
	} //selectList
	
	
	
} // class
