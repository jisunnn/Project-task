package util;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import vo.AskVO;

@Repository
public class AskDAO {
	
	@Autowired
	SqlSession sqlSession;
	private static final String NS="sdsd.mapper.AskMapper.";
	
	// ** 답글등록
	public int rinsert(AskVO vo) {
		return sqlSession.insert(NS+"replyInsert",vo);
	} //replyInsert
	
	// ** selectList
	public List<AskVO> selectList() {
		return sqlSession.selectList(NS+"selectList");
	} //selectList
	
	// ** selectOne
	public AskVO selectOne(AskVO vo) {
		return sqlSession.selectOne(NS+"selectOne", vo);
	} //selectOne 
	
	// ** insert (원글)
	public int insert(AskVO vo) {
		return sqlSession.insert(NS+"insert",vo);
	} //insert
	// ** update
	public int update(AskVO vo) {
		return sqlSession.update(NS+"update",vo);
	} //update
	// ** delete
	public int delete(AskVO vo) {
		return sqlSession.delete(NS+"delete",vo);
	} //delete
} // class
