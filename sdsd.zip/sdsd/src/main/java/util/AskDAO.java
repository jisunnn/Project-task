package util;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import vo.AskVO;
import vo.NoticeVO;
import vo.PageVO;

@Repository
public class AskDAO {
	
	@Autowired
	SqlSession sqlSession;
	private static final String NS="sdsd.mapper.AskMapper.";
	
	// ** PageList 1.
	public PageVO<AskVO> pageList(PageVO<AskVO> pvo) {
		// ** 전체Row수(totalRowCount)
		int cnta = sqlSession.selectOne(NS+"totalRowCount");
		pvo.setTotalRowCount(cnta); 
		// ** List 읽기
		List<AskVO> lista = sqlSession.selectList(NS+"pageList",pvo); 
		pvo.setList(lista);
		return pvo;
	} //pageList() 
	
	
	// ** 답글등록
	
	public int ansinsert(AskVO vo) {
		return sqlSession.insert(NS+"ansinsert",vo);
	} //replyInsert
	
	// ** selectList
	public List<AskVO> selectList() {
		return sqlSession.selectList(NS+"selectList");
	} //selectList
	
	// ** selectOne
	public AskVO selectOne(AskVO vo) {
		return sqlSession.selectOne(NS+"selectOne", vo);
	} //selectOne 
	
	// ** insert (원글)
	public int insert(AskVO vo) {
		return sqlSession.insert(NS+"insert",vo);
	} //insert
	
	// ** update
	public int update(AskVO vo) {
		return sqlSession.update(NS+"update",vo);
	} //update
	
	// ** delete
	public int delete(AskVO vo) {
		return sqlSession.delete(NS+"delete",vo);
	} //delete
	
} // class
