package util;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import vo.BoardVO;
import vo.NoticeVO;
import vo.PageVO;

//** DAO (Data Access Object)
//=> CRUD 구현 
// C: create -> insert
// R: read   -> selectList, selectOne
// U: update -> update
// D: delete -> delete

//=> 전역변수 정의 , 메서드 작성
@Repository
public class NoticeDAO {
	
	@Autowired
	SqlSession sqlSession;
	private static final String NS="sdsd.mapper.NoticeMapper.";
	
	// ** PageList 1.
	public PageVO<NoticeVO> pageList(PageVO<NoticeVO> pvo) {
		// ** 전체Row수(totalRowCount)
		int cntn = sqlSession.selectOne(NS+"totalRowCount");
		pvo.setTotalRowCount(cntn); 
		// ** List 읽기
		List<NoticeVO> listn = sqlSession.selectList(NS+"pageList",pvo); 
		pvo.setList(listn);
		return pvo;
	} //pageList() 
	
	// ** selectList
	public List<NoticeVO> selectList() {
		return sqlSession.selectList(NS+"selectList");
	} //selectList
	
	// ** selectOne
	public NoticeVO selectOne(NoticeVO vo) {
		return sqlSession.selectOne(NS+"selectOne", vo);
	} //selectOne 
	
	// ** insert (원글)
	public int insert(NoticeVO vo) {
		return sqlSession.insert(NS+"insert",vo);
	} //insert
	
	// ** update
	public int update(NoticeVO vo) {
		return sqlSession.update(NS+"update",vo);
	} //update
	
	// ** delete
	public int delete(NoticeVO vo) {
		return sqlSession.delete(NS+"delete",vo);
	} //delete
	
	// ** 조회수 증가
	public int countUp(NoticeVO vo) {
		return sqlSession.update(NS+"countUp",vo);
	} //countUp
	
	
} // class
