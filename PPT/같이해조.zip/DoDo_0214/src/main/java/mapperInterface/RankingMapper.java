package mapperInterface;

import java.util.List;

import vo.RankingVO;

public interface RankingMapper {
	
	List<RankingVO> selectList(); //selectList
	
} //interface