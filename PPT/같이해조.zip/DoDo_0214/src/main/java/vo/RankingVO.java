package vo;

import lombok.Data;

@Data
public class RankingVO {
	
	private String id;
	private int rank;
	private String nick;
	private int point;

} //class